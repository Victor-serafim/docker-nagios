<?php return array (
  'app' => 
  array (
    'name' => 'Cachet',
    'env' => 'production',
    'debug' => false,
    'url' => 'https://status.nasajon.com.br',
    'timezone' => 'UTC',
    'locale' => 'pt-BR',
    'fallback_locale' => 'en',
    'key' => 'base64:G/FiK4TiD0Tun7lTxaJXU8sg7Ok65aVX7k5N0XDha/o=',
    'cipher' => 'AES-256-CBC',
    'log' => 'errorlog',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'AltThree\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      23 => 'Barryvdh\\Cors\\ServiceProvider',
      25 => 'CachetHQ\\Badger\\BadgerServiceProvider',
      26 => 'CachetHQ\\Emoji\\EmojiServiceProvider',
      27 => 'CachetHQ\\Twitter\\TwitterServiceProvider',
      28 => 'GrahamCampbell\\Binput\\BinputServiceProvider',
      29 => 'GrahamCampbell\\Exceptions\\ExceptionsServiceProvider',
      30 => 'GrahamCampbell\\Markdown\\MarkdownServiceProvider',
      31 => 'GrahamCampbell\\Security\\SecurityServiceProvider',
      32 => 'Jenssegers\\Date\\DateServiceProvider',
      33 => 'Laravel\\Tinker\\TinkerServiceProvider',
      34 => 'McCool\\LaravelAutoPresenter\\AutoPresenterServiceProvider',
      35 => 'CachetHQ\\Cachet\\Providers\\AppServiceProvider',
      36 => 'CachetHQ\\Cachet\\Providers\\ComposerServiceProvider',
      37 => 'CachetHQ\\Cachet\\Providers\\ConsoleServiceProvider',
      38 => 'CachetHQ\\Cachet\\Providers\\ConfigServiceProvider',
      39 => 'CachetHQ\\Cachet\\Providers\\EventServiceProvider',
      40 => 'CachetHQ\\Cachet\\Providers\\IntegrationServiceProvider',
      41 => 'CachetHQ\\Cachet\\Providers\\RepositoryServiceProvider',
      42 => 'CachetHQ\\Cachet\\Providers\\RouteServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Binput' => 'GrahamCampbell\\Binput\\Facades\\Binput',
      'Str' => 'Illuminate\\Support\\Str',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'CachetHQ\\Cachet\\Models\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'avatar' => 
  array (
    'driver' => 'gd',
    'ascii' => false,
    'shape' => 'circle',
    'width' => 100,
    'height' => 100,
    'chars' => 2,
    'fontSize' => 48,
    'uppercase' => false,
    'fonts' => 
    array (
      0 => 'OpenSans-Bold.ttf',
      1 => 'rockwell.ttf',
    ),
    'foregrounds' => 
    array (
      0 => '#FFFFFF',
    ),
    'backgrounds' => 
    array (
      0 => '#f44336',
      1 => '#E91E63',
      2 => '#9C27B0',
      3 => '#673AB7',
      4 => '#3F51B5',
      5 => '#2196F3',
      6 => '#03A9F4',
      7 => '#00BCD4',
      8 => '#009688',
      9 => '#4CAF50',
      10 => '#8BC34A',
      11 => '#CDDC39',
      12 => '#FFC107',
      13 => '#FF9800',
      14 => '#FF5722',
    ),
    'border' => 
    array (
      'size' => 1,
      'color' => 'foreground',
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'null',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'apc',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/var/www/html/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'password' => NULL,
        'port' => 6379,
        'database' => 0,
      ),
    ),
    'prefix' => 'laravel',
  ),
  'cachet' => 
  array (
    'timezone' => 'America/Sao_Paulo',
    'is_docker' => true,
    'beacon' => true,
  ),
  'compile' => 
  array (
    'files' => 
    array (
    ),
    'providers' => 
    array (
    ),
  ),
  'cors' => 
  array (
    'supportsCredentials' => false,
    'allowedOrigins' => 
    array (
      0 => '*',
    ),
    'allowedOriginsPatterns' => 
    array (
    ),
    'allowedHeaders' => 
    array (
      0 => 'X-Cachet-Token',
    ),
    'allowedMethods' => 
    array (
      0 => '*',
    ),
    'exposedHeaders' => 
    array (
    ),
    'maxAge' => 3600,
    'paths' => 
    array (
      'api/v1/*' => 
      array (
        'allowedOrigins' => 
        array (
          0 => 'https://status.nasajon.com.br',
        ),
      ),
    ),
  ),
  'database' => 
  array (
    'default' => 'pgsql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => 'postgres',
        'prefix' => '',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => '167.99.61.77',
        'unix_socket' => NULL,
        'port' => '5432',
        'database' => 'postgres',
        'username' => 'postgres',
        'password' => 'CaracaBanco',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => 'chq_',
        'strict' => false,
        'engine' => NULL,
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => '167.99.61.77',
        'port' => '5432',
        'database' => 'postgres',
        'username' => 'postgres',
        'password' => 'CaracaBanco',
        'charset' => 'utf8',
        'prefix' => 'chq_',
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'default' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => 6379,
        'database' => 0,
      ),
    ),
  ),
  'debugbar' => 
  array (
    'enabled' => NULL,
    'except' => 
    array (
      0 => 'telescope*',
      1 => 'horizon*',
    ),
    'storage' => 
    array (
      'enabled' => true,
      'driver' => 'file',
      'path' => '/var/www/html/storage/debugbar',
      'connection' => NULL,
      'provider' => '',
    ),
    'include_vendors' => true,
    'capture_ajax' => true,
    'add_ajax_timing' => false,
    'error_handler' => false,
    'clockwork' => false,
    'collectors' => 
    array (
      'phpinfo' => true,
      'messages' => true,
      'time' => true,
      'memory' => true,
      'exceptions' => true,
      'log' => true,
      'db' => true,
      'views' => true,
      'route' => true,
      'auth' => true,
      'gate' => true,
      'session' => true,
      'symfony_request' => true,
      'mail' => true,
      'laravel' => false,
      'events' => false,
      'default_request' => false,
      'logs' => false,
      'files' => false,
      'config' => false,
    ),
    'options' => 
    array (
      'auth' => 
      array (
        'show_name' => true,
      ),
      'db' => 
      array (
        'with_params' => true,
        'backtrace' => true,
        'timeline' => false,
        'explain' => 
        array (
          'enabled' => false,
          'types' => 
          array (
            0 => 'SELECT',
          ),
        ),
        'hints' => true,
      ),
      'mail' => 
      array (
        'full_log' => false,
      ),
      'views' => 
      array (
        'data' => false,
      ),
      'route' => 
      array (
        'label' => true,
      ),
      'logs' => 
      array (
        'file' => NULL,
      ),
    ),
    'inject' => true,
    'route_prefix' => '_debugbar',
    'route_domain' => NULL,
    'theme' => 'auto',
  ),
  'emoji' => 
  array (
    'token' => NULL,
    'connection' => NULL,
    'key' => 'emoji',
    'life' => 10080,
  ),
  'exceptions' => 
  array (
    'transformers' => 
    array (
      0 => 'GrahamCampbell\\Exceptions\\Transformers\\AuthTransformer',
      1 => 'GrahamCampbell\\Exceptions\\Transformers\\CsrfTransformer',
      2 => 'GrahamCampbell\\Exceptions\\Transformers\\ModelTransformer',
      3 => 'CachetHQ\\Cachet\\Exceptions\\Transformers\\BusTransformer',
    ),
    'displayers' => 
    array (
      0 => 'CachetHQ\\Cachet\\Exceptions\\Displayers\\MaintenanceDisplayer',
      1 => 'CachetHQ\\Cachet\\Exceptions\\Displayers\\SettingsDisplayer',
      2 => 'CachetHQ\\Cachet\\Exceptions\\Displayers\\RedirectDisplayer',
      3 => 'CachetHQ\\Cachet\\Exceptions\\Displayers\\ThrottleDisplayer',
      4 => 'CachetHQ\\Cachet\\Exceptions\\Displayers\\JsonValidationDisplayer',
      5 => 'GrahamCampbell\\Exceptions\\Displayers\\DebugDisplayer',
      6 => 'GrahamCampbell\\Exceptions\\Displayers\\HtmlDisplayer',
      7 => 'GrahamCampbell\\Exceptions\\Displayers\\JsonDisplayer',
      8 => 'GrahamCampbell\\Exceptions\\Displayers\\JsonApiDisplayer',
    ),
    'filters' => 
    array (
      0 => 'GrahamCampbell\\Exceptions\\Filters\\VerboseFilter',
      1 => 'GrahamCampbell\\Exceptions\\Filters\\CanDisplayFilter',
      2 => 'GrahamCampbell\\Exceptions\\Filters\\ContentTypeFilter',
      3 => 'CachetHQ\\Cachet\\Exceptions\\Filters\\ApiFilter',
    ),
    'default' => 'GrahamCampbell\\Exceptions\\Displayers\\HtmlDisplayer',
    'levels' => 
    array (
      'Illuminate\\Auth\\Access\\AuthorizationException' => 'warning',
      'Illuminate\\Database\\Eloquent\\ModelNotFoundException' => 'warning',
      'Illuminate\\Session\\TokenMismatchException' => 'notice',
      'Symfony\\Component\\HttpKernel\\Exception\\HttpExceptionInterface' => 'notice',
      'Symfony\\Component\\Debug\\Exception\\FatalErrorException' => 'critical',
      'Exception' => 'error',
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/storage/app',
      ),
      'database' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/database/backups',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/var/www/html/storage/app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
      ),
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'langs' => 
  array (
    'af' => 
    array (
      'name' => 'Afrikaans',
      'subset' => 'latin',
    ),
    'ar' => 
    array (
      'name' => 'Arabic',
      'subset' => 'latin',
    ),
    'ca' => 
    array (
      'name' => 'Catalan',
      'subset' => 'latin',
    ),
    'cs' => 
    array (
      'name' => 'Czech',
      'subset' => 'latin,latin-ext',
    ),
    'da' => 
    array (
      'name' => 'Danish',
      'subset' => 'latin,latin-ext',
    ),
    'de' => 
    array (
      'name' => 'Deutsch',
      'subset' => 'latin,latin-ext',
    ),
    'el' => 
    array (
      'name' => 'Greek',
      'subset' => 'greek,greek-ext',
    ),
    'en' => 
    array (
      'name' => 'English',
      'subset' => 'latin',
    ),
    'en-UD' => 
    array (
      'name' => 'CrowdIn - InContext Localization',
      'subset' => 'latin',
    ),
    'es' => 
    array (
      'name' => 'Español',
      'subset' => 'latin,latin-ext',
    ),
    'fa' => 
    array (
      'name' => 'Persian',
      'subset' => 'latin',
    ),
    'fi' => 
    array (
      'name' => 'Finnish',
      'subset' => 'latin,latin-ext',
    ),
    'fr' => 
    array (
      'name' => 'Français',
      'subset' => 'latin,latin-ext',
    ),
    'he' => 
    array (
      'name' => 'Hebrew',
      'subset' => 'latin',
    ),
    'hu' => 
    array (
      'name' => 'Hungarian',
      'subset' => 'latin,latin-ext',
    ),
    'id' => 
    array (
      'name' => 'Indonesian',
      'subset' => 'latin',
    ),
    'it' => 
    array (
      'name' => 'Italiano',
      'subset' => 'latin,latin-ext',
    ),
    'ja' => 
    array (
      'name' => 'Japanese',
      'subset' => 'latin',
    ),
    'ko' => 
    array (
      'name' => '한글',
      'subset' => 'latin',
    ),
    'ms' => 
    array (
      'name' => 'Malay',
      'subset' => 'latin',
    ),
    'nl' => 
    array (
      'name' => 'Nederlands',
      'subset' => 'latin,latin-ext',
    ),
    'no' => 
    array (
      'name' => 'Norwegian',
      'subset' => 'latin,latin-ext',
    ),
    'pl' => 
    array (
      'name' => 'Polski',
      'subset' => 'latin,latin-ext',
    ),
    'pt-BR' => 
    array (
      'name' => 'Portuguese, Brazilian',
      'subset' => 'latin,latin-ext',
    ),
    'pt-PT' => 
    array (
      'name' => 'Portuguese, Portugal',
      'subset' => 'latin,latin-ext',
    ),
    'ro' => 
    array (
      'name' => 'Romanian',
      'subset' => 'latin,latin-ext',
    ),
    'ru' => 
    array (
      'name' => 'Русский',
      'subset' => 'latin,cyrillic',
    ),
    'sq' => 
    array (
      'name' => 'Albanian',
      'subset' => 'latin,latin-ext',
    ),
    'sr' => 
    array (
      'name' => 'Sebrian (Cyrillic)',
      'subset' => 'latin,cyrillic,cyrillic-ext',
    ),
    'sv-SE' => 
    array (
      'name' => 'Swedish',
      'subset' => 'latin,latin-ext',
    ),
    'tr' => 
    array (
      'name' => 'Turkish',
      'subset' => 'latin,latin-ext',
    ),
    'uk' => 
    array (
      'name' => 'Ukranian',
      'subset' => 'latin,cyrillic-ext',
    ),
    'vi' => 
    array (
      'name' => 'Vietnamese',
      'subset' => 'latin,vietnamese',
    ),
    'zh-CN' => 
    array (
      'name' => '简体中文',
      'subset' => 'latin',
    ),
    'zh-TW' => 
    array (
      'name' => '繁體中文',
      'subset' => 'latin',
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/var/www/html/storage/logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/var/www/html/storage/logs/laravel.log',
        'level' => 'debug',
        'days' => 7,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
      'bugsnag' => 
      array (
        'driver' => 'bugsnag',
      ),
      'debug' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'bugsnag',
          1 => 'single',
        ),
      ),
    ),
  ),
  'mail' => 
  array (
    'driver' => 'smtp',
    'host' => 'localhost',
    'port' => '25',
    'from' => 
    array (
      'address' => 'notify@status.nasajon.com.br',
      'name' => 'Cachet',
    ),
    'encryption' => 'tls',
    'username' => NULL,
    'password' => NULL,
    'sendmail' => '/usr/sbin/sendmail -bs',
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/var/www/html/resources/views/vendor/mail',
      ),
    ),
  ),
  'markdown' => 
  array (
    'views' => false,
    'extensions' => 
    array (
      1 => 'CachetHQ\\Twitter\\TwitterExtension',
    ),
    'renderer' => 
    array (
      'block_separator' => '
',
      'inner_separator' => '
',
      'soft_break' => '

',
    ),
    'enable_em' => true,
    'enable_strong' => true,
    'use_asterisk' => true,
    'use_underscore' => true,
    'html_input' => 'strip',
    'allow_unsafe_links' => false,
    'max_nesting_level' => INF,
  ),
  'queue' => 
  array (
    'default' => 'database',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => 'your-public-key',
        'secret' => 'your-secret-key',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
      ),
    ),
    'failed' => 
    array (
      'database' => 'pgsql',
      'table' => 'failed_jobs',
    ),
  ),
  'security' => 
  array (
    'evil' => 
    array (
      0 => '(?<!\\w)on\\w*',
      1 => 'style',
      2 => 'xmlns',
      3 => 'formaction',
      4 => 'form',
      5 => 'xlink:href',
      6 => 'FSCommand',
      7 => 'seekSegmentTime',
    ),
  ),
  'services' => 
  array (
    'github' => 
    array (
      'token' => NULL,
    ),
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
    ),
    'mandrill' => 
    array (
      'secret' => NULL,
    ),
    'nexmo' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'sms_from' => 'Cachet',
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
  ),
  'session' => 
  array (
    'driver' => 'apc',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/var/www/html/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
  ),
  'setting' => 
  array (
    'dashboard_login_link' => true,
    'enable_subscribers' => false,
    'suppress_notifications_in_maintenance' => true,
    'automatic_localization' => false,
    'show_support' => false,
    'enable_external_dependencies' => true,
    'show_timezone' => true,
    'skip_subscriber_verification' => false,
    'only_disrupted_days' => false,
    'always_authenticate' => false,
    'app_name' => 'Nasajon Status',
    'app_timezone' => 'America/Sao_Paulo',
    'app_locale' => 'pt-BR',
    'app_incident_days' => '7',
    'app_about' => '',
    'app_refresh_rate' => '',
    'major_outage_rate' => '50',
    'display_graphs' => true,
    'app_domain' => 'https://status.nasajon.com.br',
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'dont_alias' => 
    array (
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 30,
  ),
  'twigbridge' => 
  array (
    'twig' => 
    array (
      'extension' => 'twig',
      'environment' => 
      array (
        'debug' => false,
        'charset' => 'utf-8',
        'base_template_class' => 'TwigBridge\\Twig\\Template',
        'cache' => NULL,
        'auto_reload' => true,
        'strict_variables' => false,
        'autoescape' => 'html',
        'optimizations' => -1,
      ),
      'globals' => 
      array (
      ),
    ),
    'extensions' => 
    array (
      'enabled' => 
      array (
        0 => 'TwigBridge\\Extension\\Loader\\Facades',
        1 => 'TwigBridge\\Extension\\Loader\\Filters',
        2 => 'TwigBridge\\Extension\\Loader\\Functions',
        3 => 'TwigBridge\\Extension\\Laravel\\Auth',
        4 => 'TwigBridge\\Extension\\Laravel\\Config',
        5 => 'TwigBridge\\Extension\\Laravel\\Dump',
        6 => 'TwigBridge\\Extension\\Laravel\\Input',
        7 => 'TwigBridge\\Extension\\Laravel\\Session',
        8 => 'TwigBridge\\Extension\\Laravel\\Str',
        9 => 'TwigBridge\\Extension\\Laravel\\Translator',
        10 => 'TwigBridge\\Extension\\Laravel\\Url',
      ),
      'facades' => 
      array (
      ),
      'functions' => 
      array (
        0 => 'elixir',
        1 => 'head',
        2 => 'last',
      ),
      'filters' => 
      array (
        'get' => 'data_get',
      ),
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/var/www/html/resources/views',
    ),
    'compiled' => '/var/www/html/storage/framework/views',
  ),
);
