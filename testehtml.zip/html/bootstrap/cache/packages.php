<?php return array (
  'barryvdh/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Cors\\ServiceProvider',
    ),
  ),
  'barryvdh/laravel-debugbar' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Debugbar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Debugbar' => 'Barryvdh\\Debugbar\\Facade',
    ),
  ),
  'cachethq/badger' => 
  array (
    'providers' => 
    array (
      0 => 'CachetHQ\\Badger\\BadgerServiceProvider',
    ),
  ),
  'cachethq/emoji' => 
  array (
    'providers' => 
    array (
      0 => 'CachetHQ\\Emoji\\EmojiServiceProvider',
    ),
  ),
  'cachethq/twitter' => 
  array (
    'providers' => 
    array (
      0 => 'CachetHQ\\Twitter\\TwitterServiceProvider',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'graham-campbell/binput' => 
  array (
    'providers' => 
    array (
      0 => 'GrahamCampbell\\Binput\\BinputServiceProvider',
    ),
  ),
  'graham-campbell/exceptions' => 
  array (
    'providers' => 
    array (
      0 => 'GrahamCampbell\\Exceptions\\ExceptionsServiceProvider',
    ),
  ),
  'graham-campbell/markdown' => 
  array (
    'providers' => 
    array (
      0 => 'GrahamCampbell\\Markdown\\MarkdownServiceProvider',
    ),
  ),
  'graham-campbell/security' => 
  array (
    'providers' => 
    array (
      0 => 'GrahamCampbell\\Security\\SecurityServiceProvider',
    ),
  ),
  'jenssegers/date' => 
  array (
    'providers' => 
    array (
      0 => 'Jenssegers\\Date\\DateServiceProvider',
    ),
    'aliases' => 
    array (
      'Date' => 'Jenssegers\\Date\\Date',
    ),
  ),
  'laravel/nexmo-notification-channel' => 
  array (
    'providers' => 
    array (
      0 => 'Illuminate\\Notifications\\NexmoChannelServiceProvider',
    ),
  ),
  'laravel/slack-notification-channel' => 
  array (
    'providers' => 
    array (
      0 => 'Illuminate\\Notifications\\SlackChannelServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'mccool/laravel-auto-presenter' => 
  array (
    'providers' => 
    array (
      0 => 'McCool\\LaravelAutoPresenter\\AutoPresenterServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
);