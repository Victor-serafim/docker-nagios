<?php if($componentGroups->isNotEmpty()): ?>
<?php $__currentLoopData = $componentGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $componentGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ul class="list-group components">
    <?php if($componentGroup->enabled_components->isNotEmpty()): ?>
    <li class="list-group-item group-name">
        <i class="<?php echo e($componentGroup->collapse_class); ?> group-toggle"></i>
        <strong><?php echo e($componentGroup->name); ?></strong>

        <div class="pull-right">
            <i class="ion ion-ios-circle-filled text-component-<?php echo e($componentGroup->lowest_status); ?> <?php echo e($componentGroup->lowest_status_color); ?>" data-toggle="tooltip" title="<?php echo e($componentGroup->lowest_human_status); ?>"></i>
        </div>
    </li>

    <div class="group-items <?php echo e($componentGroup->is_collapsed ? "hide" : null); ?>">
        <?php echo $__env->renderEach('partials.component', $componentGroup->enabled_components, 'component'); ?>
    </div>
    <?php endif; ?>
</ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if($ungroupedComponents->isNotEmpty()): ?>
<ul class="list-group components">
    <li class="list-group-item group-name">
        <strong><?php echo e(trans('cachet.components.group.other')); ?></strong>

        <div class="pull-right">
            <i class="ion ion-ios-circle-filled text-component-<?php echo e($ungroupedComponents->max('status')); ?> <?php echo e($ungroupedComponents->first()->status_color); ?>" data-toggle="tooltip" title="<?php echo e($ungroupedComponents->first()->human_status); ?>"></i>
        </div>
    </li>

    <?php echo $__env->renderEach('partials.component', $ungroupedComponents, 'component'); ?>
</ul>
<?php endif; ?>
