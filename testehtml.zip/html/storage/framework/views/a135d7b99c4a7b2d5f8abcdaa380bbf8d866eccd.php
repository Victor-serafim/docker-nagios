<?php if($scheduledMaintenance->isNotEmpty()): ?>
<div class="section-scheduled">
    <?php echo $__env->make('partials.schedule', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php endif; ?>
