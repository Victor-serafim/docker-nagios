<?php if($errors->any()): ?>
<?php echo $__env->make('partials.error', ['level' => 'danger', 'title' => Session::get('title'), 'message' => $errors->all(':message')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<?php if($message = Session::get('success')): ?>
<?php echo $__env->make('partials.error', ['level' => 'success', 'title' => Session::get('title'), 'message' => $message], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<?php if($message = Session::get('warning')): ?>
<?php echo $__env->make('partials.error', ['level' => 'warning', 'title' => Session::get('title'), 'message' => $message], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<?php if($message = Session::get('info')): ?>
<?php echo $__env->make('partials.error', ['level' => 'info', 'title' => Session::get('title'), 'message' => $message], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
