<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="env" content="<?php echo e(app('env')); ?>">
    <meta name="token" content="<?php echo e(csrf_token()); ?>">

    <!-- Mobile friendliness -->
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="description" content="<?php echo $__env->yieldContent('description', trans('cachet.meta.description.overview', ['app' => $appName])); ?>">

    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo $__env->yieldContent('title', $siteTitle); ?>">
    <meta property="og:image" content=" <?php echo e(asset('/img/favicon.png')); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('description', trans('cachet.meta.description.overview', ['app' => $appName])); ?>">

    <!-- Mobile IE allows us to activate ClearType technology for smoothing fonts for easy reading -->
    <meta http-equiv="cleartype" content="on">

    <meta name="msapplication-TileColor" content="<?php echo e($themeGreens); ?>" />
    <meta name="msapplication-TileImage" content="<?php echo e(asset('/img/favicon.png')); ?>" />

    <link href="<?php echo e(Request::fullUrl()); ?>" rel="canonical">

    <?php if(isset($favicon)): ?>
    <link rel="icon" href="<?php echo e(asset("/img/{$favicon}.ico")); ?>" type="image/x-icon">
    <link rel="shortcut icon" href="<?php echo e(asset("/img/{$favicon}.png")); ?>" type="image/png">
    <?php else: ?>
    <link rel="icon" href="<?php echo e(asset('/img/favicon.ico')); ?>" type="image/x-icon">
    <link rel="shortcut icon" href="<?php echo e(asset('/img/favicon.png')); ?>" type="image/png">
    <?php endif; ?>

    <link rel="apple-touch-icon" href="<?php echo e(asset('/img/apple-touch-icon.png')); ?>">
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('/img/apple-touch-icon-57x57.png')); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('/img/apple-touch-icon-72x72.png')); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('/img/apple-touch-icon-114x114.png')); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('/img/apple-touch-icon-120x120.png')); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('/img/apple-touch-icon-144x144.png')); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('/img/apple-touch-icon-152x152.png')); ?>">

    <title><?php echo $__env->yieldContent('title', $siteTitle); ?></title>

    <?php if($enableExternalDependencies): ?>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700&amp;subset=<?php echo e($fontSubset); ?>" rel="stylesheet" type="text/css">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset(mix('dist/css/app.css'))); ?> ">

    <?php echo $__env->make('partials.stylesheet', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.crowdin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php if($appStylesheet): ?>
    <style type="text/css">
    <?php echo $appStylesheet; ?>

    </style>
    <?php endif; ?>

    <script type="text/javascript">
        var Global = {};
        var refreshRate = parseInt("<?php echo e($appRefreshRate); ?>");

        function refresh() {
            window.location.reload(true);
        }

        if (refreshRate > 0) {
            setTimeout(refresh, refreshRate * 1000);
        }

        Global.locale = '<?php echo e($appLocale); ?>';
    </script>
    <script src="<?php echo e(asset(mix('dist/js/manifest.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('dist/js/vendor.js'))); ?>"></script>
</head>
<body class="status-page <?php echo $__env->yieldContent('bodyClass'); ?>">
    <?php echo $__env->yieldContent('outer-content'); ?>

    <?php echo $__env->make('partials.banner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container" id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->yieldContent('bottom-content'); ?>
    <script src="<?php echo e(asset(mix('dist/js/all.js'))); ?>"></script>
</body>
</html>
