<?php if($aboutApp): ?>
<div class="about-app">
    <h2><?php echo e(trans('cachet.about_this_site')); ?></h2>
    <?php echo $aboutApp; ?>

</div>
<?php endif; ?>

