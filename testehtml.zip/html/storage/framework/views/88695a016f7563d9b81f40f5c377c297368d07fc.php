<style type="text/css">
body.status-page {
    background-color: <?php echo e($themeBackgroundColor); ?>;
    color: <?php echo e($themeTextColor); ?>;
    <?php if($appBanner): ?>
    padding-top: 0;
    <?php endif; ?>
}
p, strong { color: <?php echo e($themeTextColor); ?> !important; }
.reds { color: <?php echo e($themeReds); ?> !important; }
.blues { color: <?php echo e($themeBlues); ?> !important; }
.greens { color: <?php echo e($themeGreens); ?> !important; }
.yellows { color: <?php echo e($themeYellows); ?> !important; }
.oranges { color: <?php echo e($themeOranges); ?> !important; }
.greys { color: <?php echo e($themeGreys); ?> !important; }
.metrics { color: <?php echo e($themeMetrics); ?> !important; }
.links { color: <?php echo e($themeLinks); ?> !important; }

/**
 * Banner background
 */
.app-banner {
    background-color: <?php echo e($themeBannerBackgroundColor); ?> !important;
}

.app-banner-padding {
    padding: <?php echo e($themeBannerPadding); ?> !important;
}

/**
 * Alert overrides.
 */
.alert {
    background-color: <?php echo e($themeYellows); ?>;
    border-color: <?php echo e(color_darken($themeYellows, -0.1)); ?>;
    color: <?php echo e(color_contrast($themeYellows)); ?>;
}
.alert.alert-success {
    background-color: <?php echo e($themeGreens); ?>;
    border-color: <?php echo e(color_darken($themeGreens, -0.1)); ?>;
    color: <?php echo e(color_contrast($themeGreens)); ?>;
}
.alert.alert-info {
    background-color: <?php echo e($themeBlues); ?>;
    border-color: <?php echo e(color_darken($themeBlues, -0.1)); ?>;
    color: <?php echo e(color_contrast($themeBlues)); ?>;
}
.alert.alert-danger {
    background-color: <?php echo e($themeReds); ?>;
    border-color: <?php echo e(color_darken($themeReds, -0.1)); ?>;
    color: <?php echo e(color_contrast($themeReds)); ?>;
}

/**
 * Button Overrides
 */
.btn.links {
    color: <?php echo e(color_darken($themeYellows, -0.3)); ?>;
}
.btn.btn-success {
    background-color: <?php echo e($themeGreens); ?>;
    border-color: <?php echo e(color_darken($themeGreens, -0.1)); ?>;
    color: <?php echo e(color_contrast($themeGreens)); ?>;
}
.btn.btn-success.links {
    color: <?php echo e(color_darken($themeGreens, -0.3)); ?>;
}
.btn.btn-success.btn-outline {
    background-color: transparent;
    border-color: <?php echo e($themeGreens); ?>;
    color: <?php echo e($themeGreens); ?>;
}
.btn.btn-success.btn-outline:hover {
    background-color: <?php echo e($themeGreens); ?>;
    border-color: <?php echo e(color_darken($themeGreens, -0.1)); ?>;
    color: <?php echo e(color_contrast($themeGreens)); ?>;
}
.btn.btn-info {
    background-color: <?php echo e($themeBlues); ?>;
    border-color: <?php echo e(color_darken($themeBlues, -0.1)); ?>;
    color: <?php echo e(color_contrast($themeBlues)); ?>;
}
.btn.btn-info.links {
    color: <?php echo e(color_darken($themeBlues, -0.3)); ?>;
}
.btn.btn-danger {
    background-color: <?php echo e($themeReds); ?>;
    border-color: <?php echo e(color_darken($themeReds, -0.1)); ?>;
    color: <?php echo e(color_contrast($themeReds)); ?>;
}
.btn.btn-danger.links {
    color: <?php echo e(color_darken($themeReds, -0.3)); ?>;
}

/**
 * Background fills Overrides
 */
.component {
    background-color: <?php echo e($themeBackgroundFills); ?>;
    border-color: <?php echo e(color_darken($themeBackgroundFills, -0.1)); ?>;
}
.sub-component {
    background-color: <?php echo e($themeBackgroundFills); ?>;
    border-color: <?php echo e(color_darken($themeBackgroundFills, -0.1)); ?>;
}
.incident {
    background-color: <?php echo e($themeBackgroundFills); ?>;
    border-color: <?php echo e(color_darken($themeBackgroundFills, -0.1)); ?>;
}
.status-icon {
    background-color: <?php echo e($themeBackgroundFills); ?>;
    border-color: <?php echo e(color_darken($themeBackgroundFills, -0.1)); ?>;
}
.panel.panel-message:before {
    border-left-color: <?php echo e($themeBackgroundFills); ?> !important;
    border-right-color: <?php echo e($themeBackgroundFills); ?> !important;
}
.panel.panel-message:after {
    border-left-color: <?php echo e($themeBackgroundFills); ?> !important;
    border-right-color: <?php echo e($themeBackgroundFills); ?> !important;
}
.footer a {
    color: <?php echo e($themeTextColor); ?>;
}
</style>
