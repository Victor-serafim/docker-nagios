<?php if($appLocale === 'en-UD' && $enableExternalDependencies): ?>
<script type="text/javascript">
    var _jipt = [];
    _jipt.push(['project', 'cachet']);
</script>
<script type="text/javascript" src="//cdn.crowdin.com/jipt/jipt.js"></script>
<?php endif; ?>
