<h4><?php echo e(formatted_date($date)); ?></h4>
<div class="timeline">
    <div class="content-wrapper">
        <?php $__empty_1 = true; $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="moment <?php echo e($loop->first ? 'first' : null); ?>">
            <div class="row event clearfix">
                <div class="col-sm-1">
                    <div class="status-icon status-<?php echo e($incident->latest_human_status); ?>" data-toggle="tooltip" title="<?php echo e($incident->latest_human_status); ?>" data-placement="left">
                        <i class="<?php echo e($incident->latest_icon); ?>"></i>
                    </div>
                </div>
                <div class="col-xs-10 col-xs-offset-2 col-sm-11 col-sm-offset-0">
                    <div class="panel panel-message incident">
                        <div class="panel-heading">
                            <?php if($currentUser): ?>
                            <div class="pull-right btn-group">
                                <a href="<?php echo e(cachet_route('dashboard.incidents.edit', ['id' => $incident->id])); ?>" class="btn btn-default"><?php echo e(trans('forms.edit')); ?></a>
                                <a href="<?php echo e(cachet_route('dashboard.incidents.delete', ['id' => $incident->id], 'delete')); ?>" class="btn btn-danger confirm-action" data-method='DELETE'><?php echo e(trans('forms.delete')); ?></a>
                            </div>
                            <?php endif; ?>
                            <?php if($incident->component): ?>
                            <span class="label label-default"><?php echo e($incident->component->name); ?></span>
                            <?php endif; ?>
                            <strong><?php echo e($incident->name); ?></strong><?php echo e($incident->isScheduled ? trans("cachet.incidents.scheduled_at", ["timestamp" => $incident->scheduled_at_diff]) : null); ?>

                            <br>
                            <small class="date">
                                <a href="<?php echo e(cachet_route('incident', ['id' => $incident->id])); ?>" class="links"><abbr class="timeago" data-toggle="tooltip" data-placement="right" title="<?php echo e($incident->timestamp_formatted); ?>" data-timeago="<?php echo e($incident->timestamp_iso); ?>"></abbr></a>
                            </small>
                        </div>
                        <div class="panel-body markdown-body">
                            <?php echo $incident->formatted_message; ?>

                        </div>
                        <?php if($incident->updates->isNotEmpty()): ?>
                        <div class="list-group">
                            <?php $__currentLoopData = $incident->updates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item incident-update-item">
                                
                                <i class="<?php echo e($update->icon); ?>" title="<?php echo e($update->human_status); ?>" data-toggle="tooltip"></i>
                                <?php echo $update->formatted_message; ?>

                                <small>
                                    <abbr class="timeago links" data-toggle="tooltip"
                                        data-placement="right" title="<?php echo e($update->timestamp_formatted); ?>"
                                        data-timeago="<?php echo e($update->timestamp_iso); ?>">
                                    </abbr>
                                </small>
                                <a href="<?php echo e($update->permalink); ?>" class="pull-right"><span class="ion-ios-arrow-right"></span></a>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="panel panel-message incident">
            <div class="panel-body">
                <p><?php echo e(trans('cachet.incidents.none')); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
