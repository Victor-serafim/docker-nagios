<?php if($stickiedIncidents->isNotEmpty()): ?>
<div class="section-stickied">
    <h1><?php echo e(trans('cachet.incidents.stickied')); ?></h1>
    <?php $__currentLoopData = $stickiedIncidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $incidents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('partials.incidents', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
