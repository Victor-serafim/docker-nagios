<?php if($appHeader): ?>
<?php echo $appHeader; ?>

<?php else: ?>
<?php if($appBanner): ?>
<div <?php if($appBannerStyleFullWidth): ?>class="app-banner"<?php endif; ?>>
    <div class="container">
        <div class="row app-banner-padding  <?php if(!$appBannerStyleFullWidth): ?> app-banner <?php endif; ?>">
            <div class="col-md-12 text-center">
                <?php if($appDomain): ?>
                <a href="<?php echo e($appDomain); ?>" class="links"><img src="data:<?php echo e($appBannerType); ?>;base64, <?php echo e($appBanner); ?>" class="banner-image img-responsive"></a>
                <?php else: ?>
                <img src="data:<?php echo e($appBannerType); ?>;base64, <?php echo e($appBanner); ?>" class="banner-image img-responsive">
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endif; ?>
