<?php if($daysToShow > 0 && $allIncidents): ?>
<div class="section-timeline">
    <h1><?php echo e(trans('cachet.incidents.past')); ?></h1>
    <?php $__currentLoopData = $allIncidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $incidents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('partials.incidents', [@compact($date), @compact($incidents)], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<nav>
    <ul class="pager">
        <?php if($canPageBackward): ?>
        <li class="previous">
            <a href="<?php echo e(cachet_route('status-page')); ?>?start_date=<?php echo e($previousDate); ?>" class="links">
                <span aria-hidden="true">&larr;</span> <?php echo e(trans('pagination.previous')); ?>

            </a>
        </li>
        <?php endif; ?>
        <?php if($canPageForward): ?>
        <li class="next">
            <a href="<?php echo e(cachet_route('status-page')); ?>?start_date=<?php echo e($nextDate); ?>" class="links">
                <?php echo e(trans('pagination.next')); ?> <span aria-hidden="true">&rarr;</span>
            </a>
        </li>
        <?php endif; ?>
    </ul>
</nav>
<?php endif; ?>
