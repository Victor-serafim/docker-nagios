<li class="list-group-item <?php echo e($component->group_id ? "sub-component" : "component"); ?> status-<?php echo e($component->status); ?>">
    <?php if($component->link): ?>
    <a href="<?php echo e($component->link); ?>" target="_blank" class="links"><?php echo $component->name; ?></a>
    <?php else: ?>
    <?php echo $component->name; ?>

    <?php endif; ?>

    <?php if($component->description): ?>
    <i class="ion ion-ios-help-outline help-icon" data-toggle="tooltip" data-title="<?php echo e($component->description); ?>" data-container="body"></i>
    <?php endif; ?>

    <div class="pull-right">
        <small class="text-component-<?php echo e($component->status); ?> <?php echo e($component->status_color); ?>" data-toggle="tooltip" title="<?php echo e(trans('cachet.components.last_updated', ['timestamp' => $component->updated_at_formatted])); ?>"><?php echo e($component->human_status); ?></small>
    </div>
</li>
