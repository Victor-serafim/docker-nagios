<div class="section-status">
    <div class="alert alert-<?php echo e($systemStatus); ?>"><?php echo e($systemMessage); ?></div>
</div>
