<?php if($appFooter): ?>
<?php echo $appFooter; ?>

<?php else: ?>
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <?php if($showSupport): ?>
                <p>
                    <?php echo trans('cachet.powered_by'); ?>

                    <?php if($showTimezone): ?>
                    <?php echo e(trans('cachet.timezone', ['timezone' => $timezone])); ?>

                    <?php endif; ?>
                </p>
                <?php endif; ?>
            </div>
            <div class="col-sm-8">
                <ul class="list-inline">
                    <?php if($currentUser || $dashboardLink): ?>
                    <li>
                        <a class="btn btn-link" href="<?php echo e(cachet_route('dashboard')); ?>"><?php echo e(trans('dashboard.dashboard')); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if($currentUser): ?>
                    <li>
                        <a class="btn btn-link" href="<?php echo e(cachet_route('auth.logout')); ?>"><?php echo e(trans('dashboard.logout')); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if($enableSubscribers): ?>
                    <li>
                        <a class="btn btn-success btn-outline" href="<?php echo e(cachet_route('subscribe')); ?>"><?php echo e(trans('cachet.subscriber.button')); ?></a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</footer>
<?php endif; ?>

<?php echo $__env->make("partials.analytics", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
