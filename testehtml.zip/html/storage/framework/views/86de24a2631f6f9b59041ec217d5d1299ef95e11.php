<?php if($displayMetrics && $appGraphs): ?>
<div class="section-metrics">
    <?php if($metrics->count() > 0): ?>
    <ul class="list-group">
        <?php $__currentLoopData = $metrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item metric" data-metric-id="<?php echo e($metric->id); ?>">
            <metric-chart :metric="<?php echo e($metric->toJson()); ?>" :theme-light="<?php echo e(json_encode($themeMetrics)); ?>" :theme="<?php echo e(json_encode(color_darken($themeMetrics, -0.1))); ?>" :theme-dark="<?php echo e(json_encode(color_darken($themeMetrics, -0.2))); ?>"></metric-chart>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>
<?php endif; ?>
